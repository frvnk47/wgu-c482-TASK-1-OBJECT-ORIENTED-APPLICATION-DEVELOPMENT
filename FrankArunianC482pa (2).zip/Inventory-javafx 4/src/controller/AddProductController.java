package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;


public class AddProductController implements Initializable {
    
    Stage stage;
    Parent scene;
    Product product = new Product();

     @FXML
    private TextField searchPartTxt;

    @FXML
    private TextField productInvTxt;

    @FXML
    private TableView<Part> choosePartTableView;

    @FXML
    private TableView<Part> associatedPartTableView;

    @FXML
    private TableColumn<?, ?> associatedPartNameCol;

    @FXML
    private TableColumn<?, ?> choosePartInvCol;

    @FXML
    private TableColumn<?, ?> associatedPartIdCol;

    @FXML
    private TextField productPriceTxt;

    @FXML
    private TableColumn<?, ?> choosePartNameCol;

    @FXML
    private TextField productMaxTxt;

    @FXML
    private TableColumn<?, ?> associatedPartPriceCol;

    @FXML
    private TableColumn<?, ?> associatedPartInvCol;

    @FXML
    private TableColumn<?, ?> choosePartPriceCol;

    @FXML
    private TextField productMinTxt;

    @FXML
    private TableColumn<?, ?> choosePartIdCol;

    @FXML
    private TextField productIdTxt;

    @FXML
    private TextField productNameTxt;
    
    //FXML onAction Events
        @FXML
    void onActionAddPartToProduct(ActionEvent event) {
            Part part = choosePartTableView.getSelectionModel().getSelectedItem();
            if (part == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a part from the list", ButtonType.OK);
                alert.showAndWait();
            }else {
                product.addAssociatedPart(part);
            }
    }



    @FXML
    void onActionRemoveAssociatedPart(ActionEvent event) {
        ObservableList<Part> associatedParts = FXCollections.observableArrayList();
        Part part = associatedPartTableView.getSelectionModel().getSelectedItem();
        if (part == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a part from the list", ButtonType.OK);
            alert.showAndWait();
        }else {
            if (showConfirmation("Confirm Deletion", "Delete", "Are you sure you want to delete this product?")) {
                for (Part p: product.getAssociatedParts()) {
                    if(p.getId() != part.getId()) {
                        associatedParts.add(p);
                    }
                }
                product.addAssociatedPart(associatedParts);
                associatedPartTableView.setItems(product.getAssociatedParts());
                associatedPartTableView.refresh();
            }
        }
    }

    @FXML
    void onActionSaveProduct(ActionEvent event) {
        try {
            product.setProductId(Integer.parseInt(productIdTxt.getText()));
            product.setProductName(productNameTxt.getText());
            product.setProductPrice(Double.parseDouble(productPriceTxt.getText()));
            product.setProductStock(Integer.parseInt(productInvTxt.getText()));
            product.setProductMax(Integer.parseInt(productMaxTxt.getText()));
            product.setProductMin(Integer.parseInt(productMinTxt.getText()));

            if (product.getProductMin() > product.getProductMax()) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Minimum must be equal to or less than maximum", ButtonType.OK);
                alert.showAndWait();
            }else if (product.getProductStock() < product.getProductMin()) {
                Alert alert = new Alert(Alert.AlertType.ERROR,"Stock is below the minimum allowable", ButtonType.OK);
                alert.showAndWait();
            }else if (product.getProductStock() > product.getProductMax()) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Stock can not be above the maximum value", ButtonType.OK);
                alert.showAndWait();
            }else {
                Inventory.getAllProducts().add(product);
                Inventory.productIdCount += 1;
                onActionDisplayMainScreen(event);
            }

        }catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, e.getMessage(), ButtonType.OK);
            alert.showAndWait();
        }
    }

    @FXML
    void onActionDisplayMainScreen(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass() .getResource("/View/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        choosePartTableView.setItems(Inventory.getAllParts());
        choosePartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        choosePartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        choosePartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        choosePartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        associatedPartTableView.setItems(product.getAssociatedParts());
        associatedPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        associatedPartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        productIdTxt.setText(""+(Inventory.productIdCount + 1));
    }



    private Part getAPartWithId(int partId){
        ObservableList<Part> allParts = Inventory.getAllParts();
        for(int i = 0; i < allParts.size(); i++){
            Part p = allParts.get(i);
            if(p.getId() == partId) {
                return p;
            }
        }
        return null;
    }

    private ObservableList<Part> searchByPartName(String partialName){
        ObservableList<Part> namedParts = FXCollections.observableArrayList();
        ObservableList<Part> allParts = Inventory.getAllParts();
        for(Part p : allParts){
            if(p.getName().contains(partialName.toLowerCase().trim())){
                namedParts.add(p);
            }
        }
        return namedParts;
    }

    public void onActionSearchPart(KeyEvent actionEvent) {
        String sp = searchPartTxt.getText();
        ObservableList<Part> searchParts = searchByPartName(sp);
        if(searchParts.size() == 0){
            try {
                int partId = Integer.parseInt(sp);
                Part p = getAPartWithId(partId);
                if (p != null) {
                    searchParts.add(p);
                }
            } catch(NumberFormatException e) {
                //ignore
            }
        }
        if (searchParts.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "No parts matches the search", ButtonType.OK);
            alert.showAndWait();
        }
        choosePartTableView.setItems(searchParts);
        searchPartTxt.setText("");

    }


    public boolean showConfirmation(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }
    
}
