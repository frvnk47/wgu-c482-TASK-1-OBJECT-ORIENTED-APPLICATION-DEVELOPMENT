package controller;

import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AddPartController implements Initializable {
    
    Stage stage;
    Parent scene;
    Part part;
    
    @FXML
    private TextField partPriceTxt;
    @FXML
    private RadioButton outSourceRBtn;

    @FXML
    private Label addPartLabel;
    
    @FXML
    private TextField partMaxTxt;

    @FXML
    private TextField partMachineIdTxt;

    @FXML
    private TextField partMinTxt;

    @FXML
    private RadioButton inHouseRBtn;

    @FXML
    private TextField partIdTxt;

    @FXML
    private TextField partNameTxt;

    @FXML
    private TextField partInvTxt;
    private boolean isOutsourced;
    private String exceptionMessage = new String();
    private int partId;


    /**
     * Handler method for save
     * @param event button event
     * @throws IOException
     */
    @FXML
    void onActionSavePart(ActionEvent event) throws IOException {
        int id = Integer.parseInt(partIdTxt.getText());
       String name = partNameTxt.getText();
     double price = Double.parseDouble(partPriceTxt.getText());
     int stock = Integer.parseInt(partInvTxt.getText());
     int min = Integer.parseInt(partMinTxt.getText());
     int max = Integer.parseInt(partMaxTxt.getText());    
   
     if(inHouseRBtn.isSelected()){
         addPartLabel.setText("Machine ID");
         int machineId = Integer.parseInt(partMachineIdTxt.getText());
         String valid = isPartValid( name,  min,  max,  stock,  price);
         if (valid.equals("")) {
             Inventory.addPart(new InHouse(id,name,price, stock,min, max,machineId));
         }else
         {
             Alert alert = new Alert(Alert.AlertType.ERROR, valid, ButtonType.OK);
             alert.showAndWait();
         }
     }
     else {
         addPartLabel.setText("Company Name");
         String companyName = partMachineIdTxt.getText();
         String valid = isPartValid( name,  min,  max,  stock,  price);


         if (valid.equals("")) {
             Inventory.addPart(new Outsourced(id,name,price, stock, min, max,companyName));
         }else
         {
             Alert alert = new Alert(Alert.AlertType.ERROR, valid, ButtonType.OK);
             alert.showAndWait();
         }
     }
        //Return to Main Screen         
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass() .getResource("/View/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
        

        }
    //Validations
     public static String isPartValid(String name, int min, int max, int inv, double price) {
        String errorMessage="";
        if (name==null) {
            errorMessage = errorMessage + ("Part name cannot be blank.");
        }
        if (inv < 1) {
            errorMessage = errorMessage + ("\nPart inventory cannot be less than 0");
        }
        if (price < 1) {
            errorMessage = errorMessage + ("\nPart price cannot be less than 0.");
        }
        if (min > max) {
            errorMessage = errorMessage + ("\nThe inventory min must be less than the inventory max");
        }
        if (inv < min || inv > max) {
            errorMessage = errorMessage + ("\nPart inventory must be between inventory min and inventory max");
        }
        return errorMessage;
    }
    

        

    
//Navigate back to Main Screen
    @FXML
    void onActionDisplayMainScreen(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass() .getResource("/View/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        partId = Inventory.getPartIdCount();
        partIdTxt.setText(String.valueOf(partId));
        // TODO
    }

    public void inHouseRBtn(javafx.scene.input.MouseEvent mouseEvent) {
        isOutsourced = false;
        addPartLabel.setText("Machine ID");
    }

    public void outSourceRBtn(MouseEvent mouseEvent) {
        isOutsourced=true;
        addPartLabel.setText("Company Name:");
    }
}
