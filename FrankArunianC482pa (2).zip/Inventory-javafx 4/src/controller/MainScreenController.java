package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import model.Inventory;
import model.Part;
import model.Product;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;



//Initialize main class
public class MainScreenController implements Initializable {

    Stage stage;
    Parent scene;

   //Part FXML items
    @FXML
    private TextField searchPartTxt;
    
    @FXML
    private TableView<Part> partTableView;
    
    @FXML
    private TableColumn<Part, Integer> partIdCol;
    
    @FXML
    private TableColumn<Part, String> partNameCol;

    @FXML
    private TableColumn<Part, Double> partPriceCol;

    @FXML
    private TableColumn<Part, Integer> partInvCol;
    
    @FXML
    private TableView<Product> productTableView;

    //Product FXML items
    @FXML
    private TextField searchProductTxt;

    @FXML
    private TableColumn<Product, Integer> productIdCol;

    @FXML
    private TableColumn<Product, String> productNameCol;

    @FXML
    private TableColumn<Product, Double> productPriceCol;
    
    @FXML
    private TableColumn<Product, Integer> productInvCol;
    
    //FXML onAction Events

    @FXML
    void onActionAddPart(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass() .getResource("/view/AddPart.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }
    
    //Navigate to ModifyPart.fxml
    @FXML
    public void onActionModifyPart(ActionEvent event) throws IOException {

       FXMLLoader loader = new FXMLLoader();
       loader.setLocation(getClass() .getResource("/view/ModifyPart.fxml"));
       loader.load();
       ModifyPartController MPController = loader.getController();
       MPController.sendPart(partTableView.getSelectionModel().getSelectedItem());

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }
    //Delete the selected part
    @FXML
    public void onActionDeletePart(ActionEvent event) {
        if (partTableView.getSelectionModel().getSelectedItem() != null) {
            if (showConfirmation("Confirm Deletion", "Confirmation", "Are you sure ?")){
                Part removePart = partTableView.getSelectionModel().getSelectedItem();
                Inventory.deletePart(removePart);
                Inventory.getAllParts().remove(removePart);
                partTableView.refresh();
            }
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a part to delete", ButtonType.OK);
            alert.showAndWait();
        }


    }

    //Search for Part 11/20
    public void onActionSearchPart(ActionEvent actionEvent) {
        String sp = searchPartTxt.getText();
        ObservableList<Part> searchParts = searchByPartName(sp);

        if(searchParts.size() == 0){
            try {
                int partId = Integer.parseInt(sp);
                Part p = getAPartWithId(partId);
                if (p != null) {
                    searchParts.add(p);
                }
            } catch(NumberFormatException e) {
                //ignore
            }
        }
        if (searchParts.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "No parts matches the search", ButtonType.OK);
            alert.showAndWait();
        }
        partTableView.setItems(searchParts);
        searchPartTxt.setText("");

    }
    //Search for a part by partial name
    private ObservableList<Part> searchByPartName(String partialName){
        System.out.println(partialName);
        ObservableList<Part> namedParts = FXCollections.observableArrayList();
        ObservableList<Part> allParts = Inventory.getAllParts();
        for(Part p : allParts){
            if(p.getName().toLowerCase().contains(partialName.toLowerCase().trim())){
                namedParts.add(p);
            }
        }
        return namedParts;
    }


    private ObservableList<Product> searchByProductName(String partialName){
        ObservableList<Product> namedProducts = FXCollections.observableArrayList();
        ObservableList<Product> allProducts = Inventory.getAllProducts();
        for(Product p : allProducts){
            if(p.getProductName().toLowerCase().contains(partialName.toLowerCase().trim())){
                namedProducts.add(p);
            }
        }
        return namedProducts;
    }
    //Search for a part by exact ID
    private Part getAPartWithId(int partId){
        ObservableList<Part> allParts = Inventory.getAllParts();
        for(int i = 0; i < allParts.size(); i++){
            Part p = allParts.get(i);
            if(p.getId() == partId) {
                return p;
            }
        }
        return null;
    }

    private Product getAProductWithId(int pId){
        ObservableList<Product> allProducts = Inventory.getAllProducts();
        for(int i = 0; i < allProducts.size(); i++){
            Product p = allProducts.get(i);
            if(p.getProductId() == pId) {
                return p;
            }
        }
        return null;
    }


    
    //Navigate to AddProduct.fxml
    @FXML
    public void onActionAddProduct(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass() .getResource("/view/AddProduct.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }
    //Navigate to ModifyProduct.fxml
    @FXML
    public void onActionModifyProduct(ActionEvent event) throws IOException {

        Product product = productTableView.getSelectionModel().getSelectedItem();

        if(product == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a product from the list", ButtonType.OK);
            alert.showAndWait();
        }else {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass() .getResource("/view/ModifyProduct.fxml"));
            loader.load();
            ModifyProductController controller = loader.getController();
            controller.setProduct(product);
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();
        }

        
     

    }
    //Delete the selected product
    @FXML
    void onActionDeleteProduct(ActionEvent event) {
        Product product;
        if( (product = productTableView.getSelectionModel().getSelectedItem()) != null) {
            if (showConfirmation("Confirm Deletion", "Confirmation", "Are you sure ?")) {

                if (product.getAssociatedParts().size() > 0) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You can not delete this product because it has associated parts", ButtonType.OK);
                    alert.showAndWait();
                }else {
                    Inventory.deleteProduct(product);
                    Inventory.getAllProducts().remove(product);
                    productTableView.refresh();
                }

            }
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a product to delete", ButtonType.OK);
            alert.showAndWait();
        }
    }
    
//Exit the Application
    @FXML
    public void onActionExit(ActionEvent event) {
        System.exit(0);
    }

    public void initialize() {
        



    
    //Fill tables with data
    }
    
    public void updateProductTableView() {
        productTableView.setItems(Inventory.getAllProducts());
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Part Table
        partTableView.setItems(Inventory.getAllParts());
        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        partInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));


        //Product Table
        productTableView.setItems(Inventory.getAllProducts());
        productIdCol.setCellValueFactory(new PropertyValueFactory<>("productId"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
        productInvCol.setCellValueFactory(new PropertyValueFactory<>("productStock"));
    }

    public void onActionSearchProduct(ActionEvent actionEvent) {
        String sp = searchProductTxt.getText();
        ObservableList<Product> searchProducts = searchByProductName(sp);

        if(searchProducts.size() == 0){
            try {
                int pId = Integer.parseInt(sp);
                Product p = getAProductWithId(pId);
                if (p != null) {
                    searchProducts.add(p);
                }
            } catch(NumberFormatException e) {
                //ignore
            }
        }

        if (searchProducts.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "No product matches the search", ButtonType.OK);
            alert.showAndWait();
        }
        productTableView.setItems(searchProducts);
        searchProductTxt.setText("");
    }


    public boolean showConfirmation(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }
}

 
