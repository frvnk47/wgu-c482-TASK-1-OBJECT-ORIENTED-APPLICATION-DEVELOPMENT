package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Part;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ModifyPartController implements Initializable {
    @FXML
    private Label addPartLabel;
    Stage stage;
    Parent scene;
    @FXML
    private TextField partPriceTxt;

    @FXML
    private RadioButton outSourceRBtn;

    @FXML
    private TextField partMaxTxt;

    @FXML
    private TextField partMachineIdTxt;

    @FXML
    private TextField partMinTxt;

    @FXML
    private RadioButton inHouseRBtn;

    @FXML
    private TextField partIdTxt;

    @FXML
    private TextField partNameTxt;

    @FXML
    private TextField partInvTxt;
    
    //FXML onAction Events

    public void inHouseRBtn(javafx.scene.input.MouseEvent mouseEvent) {
        addPartLabel.setText("Machine ID");
    }

    public void outSourceRBtn(MouseEvent mouseEvent) {
        addPartLabel.setText("Company Name:");
    }
    
    @FXML
    void onActionSaveModifyPart(ActionEvent event) throws IOException {
        int id = Integer.parseInt(partIdTxt.getText());
        String name = partNameTxt.getText();
        double price = Double.parseDouble(partPriceTxt.getText());
        int stock = Integer.parseInt(partInvTxt.getText());
        int min = Integer.parseInt(partMinTxt.getText());
        int max = Integer.parseInt(partMaxTxt.getText());
        int index = Inventory.findPart(id);
        if(inHouseRBtn.isSelected()){
            addPartLabel.setText("Machine ID");
            int machineId = Integer.parseInt(partMachineIdTxt.getText());

            String valid = isPartValid( name,  min,  max,  stock,  price);
            if (valid.equals("")) {
                Inventory.updatePart(index, new InHouse(id,name,price, stock,min, max,machineId));
            }else
            {
                Alert alert = new Alert(Alert.AlertType.ERROR, valid, ButtonType.OK);
                alert.showAndWait();
            }
        }
        else {
            addPartLabel.setText("Company Name");
            String companyName = partMachineIdTxt.getText();
            String valid = isPartValid( name,  min,  max,  stock,  price);
            if (valid.equals("")) {
                Inventory.updatePart(index, new Outsourced(id,name,price, stock, min, max,companyName));
            }else
            {
                Alert alert = new Alert(Alert.AlertType.ERROR, valid, ButtonType.OK);
                alert.showAndWait();
            }

        }
        onActionDisplayMainScreen(event);

    }

    @FXML
    void onActionDisplayMainScreen(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass() .getResource("/View/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    public static String isPartValid(String name, int min, int max, int inv, double price) {
        String errorMessage="";
        if (name==null) {
            errorMessage = errorMessage + ("Part name cannot be blank.");
        }
        if (inv < 1) {
            errorMessage = errorMessage + ("\nPart inventory cannot be less than 0");
        }
        if (price < 1) {
            errorMessage = errorMessage + ("\nPart price cannot be less than 0.");
        }
        if (min > max) {
            errorMessage = errorMessage + ("\nThe inventory min must be less than the inventory max");
        }
        if (inv < min || inv > max) {
            errorMessage = errorMessage + ("\nPart inventory must be between inventory min and inventory max");
        }
        return errorMessage;
    }


    public void sendPart(Part part) {
        partIdTxt.setText(String.valueOf(part.getId()));
        partNameTxt.setText(part.getName());
        partInvTxt.setText(String.valueOf(part.getStock()));
        partPriceTxt.setText(String.valueOf(part.getPrice()));
        partMaxTxt.setText(String.valueOf(part.getMax()));
        partMinTxt.setText(String.valueOf(part.getMin()));

        if (part instanceof InHouse) {
            addPartLabel.setText("Machine Id: ");
            part = (InHouse) part;
            partMachineIdTxt.setText(""+((InHouse) part).getMachineId());
            inHouseRBtn.setSelected(true);
        }else {
            addPartLabel.setText("Company Name: ");
            part = (Outsourced) part;
            partMachineIdTxt.setText(""+((Outsourced) part).getCompanyName());
            outSourceRBtn.setSelected(true);
        }

    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }    
    
}
