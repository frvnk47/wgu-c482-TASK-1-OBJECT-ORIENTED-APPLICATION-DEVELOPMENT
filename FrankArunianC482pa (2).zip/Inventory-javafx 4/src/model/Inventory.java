package model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
/**
 *
 * @author Frank Arunian
 * WGU C482PA
 * email: farunia@wgu.edu
 * Student ID:001523317
 */
/**
 * The main Inventory class
 */
public class Inventory {
    /** List of all parts **/
    public   static ObservableList<Part> allParts = FXCollections.observableArrayList();
    /** List of all products **/
    public static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    /** Id counter attribute  for parts**/
    public static int idCount = 0;
    /** Id counter attribute for products **/
    public static int productIdCount = 0;

    /**
     *
     * @param part new part to add
     */
    public static void addPart(Part part){
      allParts.add(part);
        
    };

    /**
     *
     * @return the next parts id
     */
    public static int getPartIdCount() {
        return ++idCount;
    }

    
    private static ObservableList<Part> lookupPart = FXCollections.observableArrayList();
    
    private static ObservableList<Product> lookupProduct = FXCollections.observableArrayList();

    /**
     *
     * @param index the index in list
     * @param selectedPart the new part
     */
    public static void updatePart(int index, Part selectedPart){
        allParts.set(index, selectedPart);
    }

    /**
     *
     * @param id the id
     * @return the new part
     */
    public static int findPart(int id) {
        for (int i = 0; i< allParts.size(); i++) {
            if(allParts.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }

    /**
     *
     * @param index the index
     * @param selectedProduct the new product
     */
    public static void updateProduct(int index, Product selectedProduct){
        allProducts.set(index, selectedProduct);
        
    }

    /***
     *
     * @param id the id
     * @return the index
     */
    public static int geiProductIndex(int id) {
        for (int i = 0; i < allProducts.size(); i++) {
            if (allProducts.get(i).getProductId() == id) {
                return i;
            }
        }
        return -1;
    }


    /**
     *
     * @param selectedPart the part
     * @return boolean - found or not
     */
    public static boolean deletePart(Part selectedPart){
        boolean isFound = false;
        
        for (int i = 0; i < allProducts.size(); i++) {
            if (allProducts.get(i).getAssociatedParts().contains(selectedPart)) {
                isFound = true;
                }
            }
        return isFound;
    };

    /**
     * remove product from list
     * @param selectedProduct product to remove
     * @return found or not
     */
    public static boolean deleteProduct(Product selectedProduct){
        return false;
    };

    /**
     * //get the list of parts
     * @return list of parts
     */
    public static ObservableList<Part> getAllParts(){
        return allParts;
}

    /**
     * //get the list of products
     * @return list of products
     */
    public static ObservableList<Product> getAllProducts(){
        return allProducts;
        }
    }
 
