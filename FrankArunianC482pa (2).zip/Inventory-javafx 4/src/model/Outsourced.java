package model;
/**
 *
 * @author Frank Arunian
 * WGU C482PA
 * email: farunia@wgu.edu
 * Student ID:001523317
 */
/**
 * Models an outsourced part
 */
public class Outsourced extends Part {
    private String companyName;

    /**
     * The constructor
     * @param id part id
     * @param name part name
     * @param price the price,
     * @param stock the quantity in stock
     * @param min the minimum
     * @param max the maximum
     * @param companyName the name of the company
     */
    /**  Here I have a suggestion to improve the aesthetic and that is to add a dollar sign to the price*/
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        setId(id);
        setName(name);
        setPrice(price);
        setStock(stock);
        setMin(min);
        setMax(max);
        this.companyName=companyName;
    }

    /**
     *
     * @return company name
     */
    public String getCompanyName() {
        return companyName;
    }

    /***
     *
     * @param companyName new company name
     */

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
   
}
