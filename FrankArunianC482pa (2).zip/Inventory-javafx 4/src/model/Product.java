package model;
/**
 *
 * @author Frank Arunian
 * WGU C482PA
 * email: farunia@wgu.edu
 * Student ID:001523317
 */
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Class that models a product in the inventory
 */
public class Product extends Inventory {
    /** The parts associated with this particular product **/
    private  ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    /** product id **/
    private final IntegerProperty productId;
    /** product name **/
    private final StringProperty productName;
    /** product price **/
    private final DoubleProperty productPrice;
    /** product stock **/
    private final IntegerProperty productStock;
    /** product allowed minimum quantity **/
    private final IntegerProperty productMin;
    /** product allowed maximum quantity **/
    private final IntegerProperty productMax;


    /**
     * The constructor of the Product class
     */
    public Product(){
        productId = new SimpleIntegerProperty();
        productName = new SimpleStringProperty();
        productPrice = new SimpleDoubleProperty();
        productStock = new SimpleIntegerProperty();
        productMin = new SimpleIntegerProperty();
        productMax = new SimpleIntegerProperty();
    }
    //Declare Methods

    /**
     *
     * @return product id
     */
    public IntegerProperty productIdProperty() {
        return productId;
    }

    /**
     *
     * @return the product name
     */
    public StringProperty productNameProperty(){
        return productName;
    }

    /**
     *
     * @return the product price
     */
    public DoubleProperty productPriceProperty(){
        return productPrice;
    }

    /**
     *
     * @return the quantity in stock
     */
    public IntegerProperty productStockProperty() {
        return productStock;
    }

    /**
     *
     * @return the minimum quantity
     */
    public IntegerProperty productMinProperty() {
        return productMin;
    }

    /**
     *
     * @return the maximum quantity
     */
    
    public IntegerProperty productMaxProperty() {
        return productMax;
    }

    /**
     *
     * @return the id
     */
    public int getProductId() {
        return this.productId.get();
    }

    /**
     *
     * @return the name
     */
    public String getProductName() {
        return this.productName.get();
    }

    /**
     *
     * @return the price
     */
    public Double getProductPrice() {
        return this.productPrice.get();
    }

    /**
     *
     * @return the stock quantity
     */
    public int getProductStock() {
        return this.productStock.get();
    }

    /**
     *
     * @return the minimum
     */
    public int getProductMin() {
        return this.productMin.get();
    }

    /**
     *
     * @return the maximum
     */
     public int getProductMax() {
        return this.productMax.get();
    }

    /**
     *
     * @return the associated parts
     */
     public ObservableList<Part> getAssociatedParts(){
         return associatedParts;
     }


    /**
     *
     * @param productId new id
     */

    public void setProductId(int productId) {
         this.productId.set(productId);
     }

    /**
     *
     * @param productName new name
     */
     public void setProductName(String productName) {
         this.productName.set(productName);
     }

    /**
     *
     * @param productPrice new price
     */
     public void setProductPrice(Double productPrice) {
         this.productPrice.set(productPrice);
     }

    /**
     *
     * @param productStock new quantity
     */
    public void setProductStock(int productStock) {
         this.productStock.set(productStock);
     }

    /**
     *
     * @param productMin new minimum
     */
    public void setProductMin(int productMin){
         this.productMin.set(productMin);
     }

    /**
     *
     * @param productMax new maximum
     */
    public void setProductMax(int productMax){
         this.productMax.set(productMax); 
     }

    /**
     * Adds list of parts to the associated parts list
     * @param part the parts to be added
     */
    public void addAssociatedPart(ObservableList<Part> part){
        this.associatedParts=part;
    }

    /***
     * Adds a single part to associated parts
     * @param p the new part
     */
    public void addAssociatedPart(Part p) {
        associatedParts.add(p);
    }

    /**
     * Deletes part from the associated parts
     * @param selectedAssociatedPart the part to delete from the list.
     * @return boolean
     */
    /**Here I had some trouble deleting only a part from the deleted list so I had to specify it which corrected the logical error. */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart){
         return false;
    }

    /**
     * Gets all the associated parts
     */
    public static ObservableList<Part> getAllAssociatedParts = FXCollections.observableArrayList();
}
        
 