package model;
/**
 *
 * @author Frank Arunian
 * WGU C482PA
 * email: farunia@wgu.edu
 * Student ID:001523317
 */
/***
 * This class Models an InHouse part
 *
 */
public class InHouse extends Part {
    
    private int machineId;

    /**
     * The constructor
     * @param id part id
     * @param name part name
     * @param price the price,
     * @param stock the qucntity in stock
     * @param min the minimum
     * @param max the maximum
     * @param machineId the machine ID
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId){
        super(id, name, price, stock,  min, max);
        setId(id);
        setName(name);
        setPrice(price);
        setStock(stock);
        setMin(min);
        setMax(max);
        this.machineId=machineId;
        
    }

    /**
     * Gets machine id
     * @return machine id
     */
    public int getMachineId() {
        return machineId;
    }

    /**
     * Changes the machine ID to the argument provided
     * @param machineId integer greater than 0
     */
    public void setMachineId(int machineId) {
        this.machineId = machineId;
    }
}
